({
    doInit : function(component, event, helper) {
        helper.fetchCurrentUser(component, event);
    }
})