({
    doInit : function(component, event, helper) {
        helper.fetchEnvironmentMetadata(component, event);
    }
})