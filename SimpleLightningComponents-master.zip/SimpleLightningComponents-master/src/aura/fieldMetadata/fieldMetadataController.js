({
    doInit : function(component, event, helper) {
        helper.fetchFieldMetadata(component, event);
    }
})