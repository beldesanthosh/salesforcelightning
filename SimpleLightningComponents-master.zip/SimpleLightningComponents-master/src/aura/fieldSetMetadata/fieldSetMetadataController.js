({
    doInit : function(component, event, helper) {
        helper.fetchFieldSetMetadata(component, event);
    }
})