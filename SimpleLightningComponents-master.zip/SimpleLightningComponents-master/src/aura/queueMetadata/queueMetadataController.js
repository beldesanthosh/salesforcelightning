({
    doInit : function(component, event, helper) {
        helper.fetchQueueMetadata(component, event);
    }
})