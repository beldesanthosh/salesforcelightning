({
    doInit : function(component, event, helper) {
        helper.fetchRecordTypeMetadata(component, event);
    }
})